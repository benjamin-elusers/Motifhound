/* fasta.h Declarations for simple FASTA i/o library */
#include <stdio.h>


