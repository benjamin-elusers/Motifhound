#! /usr/bin/perl
#------------------------------------------------------------+
# Date    : 30/07/2012                                       |
# Authors : B. Dubreuil                                      |
# Contact : dubreuil.benjamin@hotmail.com                    |
#------------------------------------------------------------+
use strict;
use warnings;
BEGIN
{
	use File::Basename;
	use Cwd qw(getcwd chdir abs_path);
	use FindBin qw($Bin $Script);
	$ENV{'DIR'}=abs_path("$Bin");
	use if (exists $ENV{'SCRIPTSDIR'}), lib => $ENV{'SCRIPTSDIR'};
	use if (not exists $ENV{'SCRIPTSDIR'} and exists $ENV{'DIR'}), lib => $ENV{'DIR'};
	if(not exists $ENV{'DIR'} and not exists $ENV{'SCRIPTSDIR'}){
		die "No Environment Variable for locating Scripts Directory. Please refer to documentation.\n";
	}
	$ENV{'DATADIR'}=abs_path($ENV{'SCRIPTSDIR'}."/../Data");
}
use Getopt::Long;
use List::Util qw(first max maxstr min minstr reduce shuffle sum) ;
use List::MoreUtils qw(uniq);
use File_Utils;
use String_Print_Utils;
use Data::Dumper;

sub load_table_ppvalue {

	my ($PPvalfile) = @_;
	
	my $i=0;
	my @Nset=(5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,25,30,35,40,50,60,75,100,125,150,200);
	my %H;

	for my $n (@Nset){
		open(TAB,$PPvalfile.".N$n") or die "Unable to open Evolution file ($PPvalfile)\n";
		my @lines=<TAB>; my @c; my $li=1;
		while(@lines){
			@c=split("\t",$_);
			for($i=3;$i<$#c+4;$i++){
				my $rounded = sprintf("%.1f", $c[$i]);
				if( $c[$i] > $rounded ){ $rounded = $rounded + 0.1; }
				if( not exists $H{$n}->{$i}->{"PPval"}->{$rounded} ){
					$H{$n}->{$i}->{"PPval"}->{$rounded}->{"rank"}=$li; $H{$n}->{$i}->{"PPval"}->{$rounded}->{"#"}=1;  
				}else{
					$H{$n}->{$i}->{"PPval"}->{$rounded}->{"#"}++;
				}
			}
			$li++;
		}
	}
	
	return(\%H);
}

sub which_min {

	my ($Ref_tab) = @_;
	my @tab = @{$Ref_tab};
	my $ind = 0; my $min=0;

	foreach $ind (1..$#tab) {
		$min=$ind if $tab[$ind]<$tab[$min];
	}

	return ($min);
}

sub which {

	my ($Ref_tab,$val) = @_;
	my @tab = @{$Ref_tab}; my $ind = 0;
	my @list_ind;
	foreach $ind (0..$#tab) {
		push(@list_ind,$ind) if $tab[$ind]==$val;
	}
	return (@list_ind);
}

sub log10 {
	my $n = shift;
	return (log($n)/log(10));
}

sub load_all_motifs_in_Hash {

	my ($Motifs_file,$Smin,$Smax,$scripts,$logdir,$msg)=@_;

	my %All_MOTIFS=();
	my $nb_tot_motifs=0; my $s=3;
	my $nb_motifs_cutoff=100;
	my $nb_motifs=0; my $nb=0; my $perc=0;
	my ($fname,$dir,$ext)  = fileparse($Motifs_file,qr{\..*});
	print "\n    o Loads all motifs (from length $Smin to $Smax)...";
	for($s=$Smin; $s <= $Smax ; $s++){
		$nb_motifs=0;
		print STDERR "$msg [Loading Motif of Length $s - ".sprintf("%2d",$perc)."%]\r"; $perc=int((($s-$Smin+1)/($Smax-$Smin))*100);
		my $Ref_MOTIFS = Filter_Wildcards("$dir/$fname".".L$s",$s,$scripts,$logdir);
		my ($Ref_HMOTIFS,$nb) = load_motifs($Ref_MOTIFS); unlink("$dir/$fname".".L$s.tmp");
		my %MOTIFS = %{$Ref_HMOTIFS};
		my @Mots = sort { $MOTIFS{$a}->{"Pval"} <=> $MOTIFS{$b}->{"Pval"} || $MOTIFS{$b}->{"Cdef"} <=> $MOTIFS{$a}->{"Cdef"}} (keys (%MOTIFS));
		foreach my $motif ( @Mots ){
			if( $nb_motifs < $nb_motifs_cutoff){
				$All_MOTIFS{$motif}->{"Len"}= $MOTIFS{$motif}->{"Len"};
				$All_MOTIFS{$motif}->{"Cdef"}= $MOTIFS{$motif}->{"Cdef"};
				$All_MOTIFS{$motif}->{"S_set"}= $MOTIFS{$motif}->{"S_set"};
				$All_MOTIFS{$motif}->{"S_pop"}=$MOTIFS{$motif}->{"S_pop"};
				$All_MOTIFS{$motif}->{"N_set"}= $MOTIFS{$motif}->{"N_set"};
				$All_MOTIFS{$motif}->{"N_pop"}= $MOTIFS{$motif}->{"N_pop"};
				$All_MOTIFS{$motif}->{"Pval"}=$MOTIFS{$motif}->{"Pval"};
#				$All_MOTIFS{$motif}->{"nbdegen"}=$MOTIFS{$motif}->{"nbdegen"};
#				$All_MOTIFS{$motif}->{"Pval_adj"}=$MOTIFS{$motif}->{"Pval_adj"};
#				$All_MOTIFS{$motif}->{"nwild"}=$MOTIFS{$motif}->{"nwild"};
				$nb_tot_motifs++;	$nb_motifs++;
			}
		}
	}
	if( $nb_tot_motifs == 0 ){ print STDERR "# NO MOTIFS FOUND ! #\n-------------------\nPossible reasons :\n-------------------\n- The set might not contain enough sequences\n- The minimum number of occurence was set too high.\n- If sequence filtering was activated, the set might contain only homologuous and/or only ordered proteins.\n"; exit(-1);}
	return(\%All_MOTIFS,$nb_tot_motifs);
}

# Silent options
my $help = ""; my $quiet= "";
my $Motifs_file = "";
my $resfile  = "./Best_Motifs.html";
my $logdir   = "./";
my @Size=(3,10);

GetOptions(
	"help!"              => \$help,
	"nov|quiet!"         => \$quiet,
#	"Motifs=s"           => \$Motifs_file,
	"resfile|out:s"      => \$resfile,
	"logdir:s"           => \$logdir,
	"Size=i{2}"          => \@Size,
	)
or die "=========================\n /!\\ Incorrect Usage /!\\\n=========================\n
USAGE: ".$0." [Options]
----------------------------------------------------------------------------------------------------------------------------------------------
     Options         |  Arguments                          |  Description                                                                     
----------------------------------------------------------------------------------------------------------------------------------------------
 *  --Motifs         |  <File directory>                   |  Location of the file that contains all the over-represented Motifs              
                     |                                     |                                                                                  
    --Size           |  <Integer value>   <Integer value>  |  Minimum length and Maximum length of the Motifs                                 
                     |                                     |                                                                                  
    --out            |  <File or Path directory>           |  Location or Name of the Results file                                            
                     |                                     |                                                                                  
    --logdir         |  <Path directory>                   |  Location of the Log Directory                                                   
                     |                                     |                                                                                  
    --nov            |                                     |  Only print Logo, progression and time usage                                     
                     |                                     |                                                                                  
    --help           |                                     |  Prints the help description and exit                                            
                     |                                     |                                                                                  
----------------------------------------------------------------------------------------------------------------------------------------------
(*) Mandatory options                                                                                                                         \n";
# If the help parameter is active, the program does not run but the text above is printed to the screen.
if ($help) {
	print "	#########################################################################################################################################################\n";
	print "	#                                              Discretize PP Values - Discretization of Pseudo Pvalues -                                                #\n";
	print "	#-------------------------------------------------------------------------------------------------------------------------------------------------------#\n";
	print "	# This program takes at most 6  parameters :                                                                                                            #\n";
	print "	#   1)  --help                                     + Description of Program Usage                                                    +  (Optional)      #\n";
	print "	#   2)  --quiet,--nov                              + Non verbous Mode                                                                +  (Optional)      #\n";
	print "	#   5)  --PPval                                    + PPvalue file                                                                    +  (Mandatory)     #\n";
	print "	#   5)  --Motifs                                   + Over Representation Result File                                                 +  (Mandatory)     #\n";
	print "	#   6)  --resfile,--out                            + Location of the Result file                                                     +  (Optional)      #\n";
	print "	#   7)  --logdir                                   + Location of the Log Directory                                                   +  (Optional)      #\n";
	print "	#   8)  --Size        (From 3 to 10 by default)    + Min and Max Motifs Sizes (2 values required between 3 to 12 AA)                 +  (Optional)      #\n";
	print "	#########################################################################################################################################################\n";
	exit(0);
}

if($Motifs_file ne ""){ 

	# Non verbose mode 
	if ($quiet){
		# Redirection of printed messages to a log file ('HTML_Output.log')
		open (STDOUT,">$logdir/HTML_Output.log") or die ("Unable to redirect STDOUT to a file");
	}

	# Existence of the Motif Enumeration file
#	my ($Motifsname,$Motifsdir,$Motifsext)  = fileparse(abs_path($Motifs_file),qr{\..*});
#	print  "- Over Represented Motifs file    :  \"$Motifs_file\" => "; my ($rc_motif,$TEXT3) = File_verification($Motifs_file); print $TEXT3;
#	if($rc_motif != 0){ die "# Something wrong happened when verifying the location of the over-represented Motifs file #\n"; }
#	my ($fout,$dir,$ext)  = fileparse($resfile,qr{\..*});

#	print "  o Reading Data...[Overrepresented Motifs]                             \n";
#	my ($Ref_All_MOTIFS,$nb_motifs)=load_all_motifs_in_Hash($Motifs_file,min(@Size),max(@Size),$ENV{'SCRIPTSDIR'},$logdir,"Producing HTML Output...($dir"."$fout.html)");
#	my %All_MOTIFS = %{$Ref_All_MOTIFS};

	my $i=1; my $cpt=1; my $NSeq=0;
	my $i_motif=1; my $left_motif=$nb_motifs; my $i_ID=1;
	my $lien_domain=""; my $lien_ID="";

	my($ppname,$ppdir,$ppext)=fileparse($PPvalfile,qr{\..*});
	my $Uniprot_link = "href=\"http://www.uniprot.org/uniprot/";
	my $SGD_link = "href=\"http://www.yeastgenome.org/cgi-bin/locus.fpl?locus=";
	my $PFAM_link="http://pfam.sanger.ac.uk/search/jump?entry=";
	print "\n\n";

	my %Table = %{load_table_ppvalue($ppdir.$ppname)};
	my $pval_ex=1.985164*(10**-8); my $rounded_pval = sprintf("%.1f",1.985164*(10**-8));
	if( $pval_ex > $rounded_pval ){ $rounded_pval = $rounded_pval + 0.1; }
	my $N=15; my $L=8; my $D=5;
	
	print STDERR "$pval_ex ( rounded = $rounded_pval ) => A...DVFP N=15 L=8 D=5\n \t\t\t\t\tRank : ".$Table{$N}->{$D}->{"rank"}."\t\t\t\t\t".$Table{$N}->{$D}->{""}

}else{
	print "\n".format_string(70,"#","#","#",">");
	print "\n".format_string(70,"#    For more details, consult the help to launch the program :"," ","#",">");
	print "\n".format_string(70,"#        $0       --help"," ","#",">");
	print "\n".format_string(70,"#","#","#",">")."\n\n";
	exit(0);
}
