Author : Dubreuil Benjamin
Mail: dubreuil.benjamin@hotmail.com
CANADA : Centre Robert Cedegren - Université de Montréal (Dept. de Biochimie - Michnick Lab)
ISRAEL : Weizmann Institute of Science - (Strutural Biology Dept. - E. Levy Lab)
#####################################################################
########### BENCHMARK DATASETS FOR LINEAR MOTIF DISCOVERY ###########
#####################################################################

In order to evaluate which computational method gives the most        
accurate results, we performed a benchmark using artificial datasets  
designed for this task. 

To have a trustworthy comparison of each program’s performances, we   
created adapted datasets which match the input requirements of each   
program. The results of this study are only based on the ability for  
each method to recover the artificially created motifs that we have   
spiked-in in a large-scale dataset. This study is constrained on the  
primary structure of proteins from S. cerevisae.

Creating artificial datasets for motif discovery requires taking into 
account the challenge raised by the short and degenerate nature of    
SLiMs, and the pitfall resulting from maximization of signal-to-noise 
ratio between artificially inserted motifs and already present motifs.

To reduce calculation time, we chose to conserve only sequences with a
 length superior to 100 AAs and inferior to 500 AAs. So, the proteome 
used is composed by 3000 sequences, distributed over 30 sets of 100   
sequences. The sequence selection for each of the 30 sets has been    
made randomly. In that way, we have tried to avoid the enrichment of  
initial motifs in those sets. The average length of all sequences is  
296±111 AAs and the total number of AAs is 888576.
The benchmark datasets were designed in order to create new artificial
Linear Motifs by varying three major characteristics : 
the motif length, the number of fixed positions and the abundance rate.


/ 1st parameter : Motif Length                                       /
======================================================================
The range of artificial motif lengths varies from 3 to 10 residues.  

/ 2nd parameter : Number of fixed positions (non wildcard positions) /
======================================================================
The range of number of positions with restricted identity, also called
 fixed positions, varies from 3 to the motif length.

/ 3rd parameter : Motif Abundance Rate (Number of repetitions)       /
======================================================================
Finally, each motif has been inserted multiple times in sets of 100   
sequences. The number of occurrences of each inserted motif varies    
from 3, 4, 5, 6, 7, 8, 10, 12, 15, 20 and 30 times in a set of 100    
sequences.


First, we created patterns of length from 3 to 10 residues, with fixed
 positions varying from 3 to the motif length. For each pattern,      
30 unique motifs have been generated and each one has been inserted   
with a different number of repetitions in each of the 30 sets of 100   
sequences. 

Altogether, the benchmark dataset is composed of 11880 sets of 100    
sequences with unique motif inserted with a different abundance rate  
for each set. To compute an accuracy value, we took only the most     
significant motif found by the programs for each set of 100 sequences 
and we compared it to the artificial motif inserted in this set.      

----------------------------------------------------------------------
                        Content of the archive                        

=========================
/1/ "Control" directory 
=========================
This directory contains the 30 sets of 100 sequences extracted from   
the Yeast Proteome. Each one has been named like this :
                "Reference_Seq_x.faa"                   
where "x" is a number comprised between 1 and 30.
The file "Reference_Seq_all.faa" contains the 3000 sequences
and should be representative of the yeast Proteome.

===========================
/2/ "Motif_Benchmark" directory
===========================
This contains all the patterns that have been designed before their   
insertion in the sequences. They have been sorted by length, and named
like this :
                      "Motif_bench_Ss_Rr_Cc.mot"                      
where "s" is the length of those patterns, "r" is the motif abundance 
rate and "c" is the number of fixed positions 

( c does not take into account the positions at the extremities of the
motif because we consider that a motif is of fixed length with at     
least two fixed positions at the extremities.)

==============================
/3/ "Motif_Inserted" directory
==============================
This contains files that summarizes for each set:
- The pattern that have been inserted,
- The ORF where it has been inserted,
- The positions in the ORF where the pattern has been inserted,
- The artificial motif created with the insertion of the pattern,
- The original sequence which was replaced,
- The length of the newly created motif,
- The disorder observed at this location,
(0 is for ordered regions otherwise the regions are disordered)
- two columns that were used for debugging and to control if the      
insertion went well (columns with headers "pos_all_seq")


The files names look like this :
                      "inserted_motifs_Ss_Rr_Cc_k.txt"                   
"s", "r", "c" have the same signification as described above.
"k" is referred to one of the 30 sets of 100 sequences.

===========================
/4/ "Sequence_Motifs" directory
===========================
This directory contains the modified set of 100 sequences with the arti-
ficial motifs inserted in those sequences. The same convention was used 
for naming the sequence files.

The files names look like this :
                       "Sequence_Motifs_Ss_Rr_Cc_k.faa"                
"s", "r", "c" have the same signification as described above.
"k" is referred to one of the 30 sets of 100 sequences.
-----------------------------------------------------------------------
